package sobrecarga;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Calculo obj =new Calculo();
        
        System.out.printf ("A média com 2: %.2f.\n", obj.media(2, 3));
        System.out.printf ("A média com 3: %.2f.\n", obj.media(2, 3, 4));
        System.out.printf ("A média com 4: %.2f.\n", obj.media(2, 3, 4, 5));
    }
    
}
