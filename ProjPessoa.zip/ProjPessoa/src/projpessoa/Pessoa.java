package projpessoa;

public class Pessoa {
    public String nome;
    public double altura;
    public int idade;
    
    public Pessoa (String nome, double altura, int idade){
        this.nome=nome;
        this.altura=altura;
        this.idade=idade;
    }
    
    public Pessoa (String nome, int idade){
        this.nome=nome;
        this.altura=0.0;
        this.idade=idade;
    }
    
    public Pessoa (String nome, double altura){
        this.nome=nome;
        this.altura=altura;
        this.idade=0;
    }
    
    public Pessoa (String nome){
        this.nome=nome;
        this.altura=0.0;
        this.idade=0;
    }
    
    @Override
    public String toString(){
        if (altura > 0.0){
        return String.format("%s mede %.2fm e tem %d anos", nome, altura, idade);
        }
        else{
            return String.format ("%s tem %d anos", nome, idade);
        }
    }
}
