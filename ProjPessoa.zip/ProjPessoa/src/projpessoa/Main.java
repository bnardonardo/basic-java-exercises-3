package projpessoa;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        Pessoa P=new Pessoa("Bernardo", 1.80, 21);
        System.out.printf ("%s.\n", P);
        
        Pessoa Q=new Pessoa("Bernardo", 21);
        System.out.printf ("%s.\n", Q);
    }
    
}
