package retangulo;

public class Retangulo {
    public double base;
    public double altura;
    public double A;
    public double P;
    
    public Retangulo (){
        base=0.0;
        altura=0.0;
    }
    
    public Retangulo(double base, double altura){
        this.base=base;
        this.altura=altura;
    }
    
    public void perimetro (){
        P=2*(base+altura);
        System.out.printf ("O cálculo do perímetro é: %.2f\n",P);
    }
    
    public void area (){
        A=base*altura;
        System.out.printf ("O Cálculo da área é: %.2f\n", A);
    }
    
    @Override
    public String toString(){
        perimetro();
        area();
        return String.format ("Um retângulo de base %.2f e altura %.2f tem perímetro de %.2f e área de %.2f", base, altura, P, A);
    }
}
