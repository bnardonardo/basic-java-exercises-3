package tempo;

public class Tempo {
    public int hora;
    public int minutos;
    public int segundos;
    
    public Tempo (int hora){
        this.hora=hora;
        this.minutos=0;
        this.segundos=0;
    }
    
    public Tempo (int hora, int minutos){
        this.hora=hora;
        this.minutos=minutos;
        this.segundos=0;
    }
    
    public Tempo (int hora, int minutos, int segundos){
        this.hora=hora;
        this.minutos=minutos;
        this.segundos=segundos;
    }
    
    @Override
    public String toString(){
        if (minutos == 0 && segundos == 0){
            return String.format ("%s", hora);
        }
        else if (segundos == 0){
            return String.format ("%s:%s", hora, minutos);
        }
        else {
            return String.format ("%s:%s:%s", hora, minutos, segundos);
        }
    }
}
