package tempo;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Tempo sohora=new Tempo (16);
        Tempo horamin=new Tempo (16, 30);
        Tempo completo = new Tempo (16, 30, 15);
        
        System.out.printf ("%s \n", sohora);
        System.out.printf ("%s \n", horamin);
        System.out.printf ("%s \n", completo);
    }
    
}
