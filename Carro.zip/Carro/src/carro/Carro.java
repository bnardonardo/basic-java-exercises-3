package carro;

public class Carro {
    public String modelo;
    public int ano;
    public String tanque;
    public double consumo;
    
    public Carro (String modelo, int ano, String tanque, double consumo){
        this.modelo=modelo;
        this.ano=ano;
        this.tanque=tanque;
        this.consumo=consumo;
        
    }
    
    public Carro (int ano, String tanque, double consumo){
        this.modelo="null";
        this.ano=ano;
        this.tanque=tanque;
        this.consumo=consumo;
        
    }
    
    public Carro (String modelo, String tanque, double consumo){
        this.modelo=modelo;
        this.ano=0;
        this.tanque=tanque;
        this.consumo=consumo;
        
    }
    
    @Override 
    public String toString(){
        
    if (ano == 0){
        return String.format ("Modelo: %s. Ano: Não listado. Tanque: %s. Consumo: %.2f", modelo, tanque, consumo);
    }
        
    else if (modelo == "null"){
            return String.format ("Modelo: Não listado. Ano: %d. Tanque: %s. Consumo: %.2f", ano, tanque, consumo);   
    }
        else {
            return String.format ("Modelo: %s. Ano: %d. Tanque: %s. Consumo: %.2f", modelo, ano, tanque, consumo);
        }
    
				}
}
