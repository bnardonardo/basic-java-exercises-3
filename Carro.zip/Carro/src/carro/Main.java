package carro;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Carro fiat=new Carro("fiat", 1999, "v17", 233);
        Carro bbb=new Carro(1990, "tq4", 679);
        Carro jao=new Carro("Job", "gg", 899);
        
        System.out.printf ("%s \n", fiat);
        System.out.printf ("%s \n", bbb);
        System.out.printf ("%s \n", jao);
    }
    
}
